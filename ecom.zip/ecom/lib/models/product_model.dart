import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class Product extends Equatable {
  final String name;
  final String category;
  final String imageUrl;
  final double price;
  final bool isRecommended;
  final bool isPopular;

  const Product({
    required this.name,
    required this.price,
    required this.category,
    required this.imageUrl,
    required this.isPopular,
    required this.isRecommended,
  });
  

  static Product fromSnapShot(DocumentSnapshot snap) {
    Product product = Product(
      name: snap['name'],
      price: snap['price'],
      category: snap['category'],
      imageUrl: snap['imageUrl'],
      isPopular: snap['isPopular'],
      isRecommended: snap['isRecommended'],
    );
    return product;
  }

  @override
  List<Object?> get props =>
      [name, category, imageUrl, price, isRecommended, isPopular];

  static List<Product> products = [
    Product(
        name: 'Soft Drink 1',
        price: 20,
        category: 'Soft Drinks',
        imageUrl: 'https://unsplash.com/photos/D8XcEUt3Tmc',
        isPopular: false,
        isRecommended: true),
    Product(
        name: 'Soft Drink 2',
        price: 20,
        category: 'Soft Drinks',
        imageUrl: 'https://unsplash.com/photos/CqY5To2ZU8E',
        isPopular: false,
        isRecommended: true),
    Product(
        name: 'Soft Drink 3',
        price: 20,
        category: 'Soft Drinks',
        imageUrl: 'https://unsplash.com/photos/UTsEMue2jXE',
        isPopular: true,
        isRecommended: true),
    Product(
        name: 'Smoothie 1',
        price: 50,
        category: 'Smoothies',
        imageUrl: 'https://unsplash.com/photos/9Gz5bMWdGYE',
        isPopular: false,
        isRecommended: true),
    Product(
        name: 'Smoothie 2',
        price: 50,
        category: 'Smoothies',
        imageUrl: 'https://unsplash.com/photos/h6ccJcVHh20',
        isPopular: false,
        isRecommended: false),
  ];
}
