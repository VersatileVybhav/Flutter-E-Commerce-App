import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class Category extends Equatable {
  final String name;
  final String imageUrl;

  const Category({
    required this.name,
    required this.imageUrl,
  });

  @override
  List<Object?> get props => [name, imageUrl];

  static Category fromSnapShot(DocumentSnapshot snap) {
    Category category = Category(
      name: snap['name'],
      imageUrl: snap['imageUrl'],
    );
    return category;
  }

  static List<Category> categories = [
    Category(
        name: 'Soft Drink',
        imageUrl: 'https://unsplash.com/photos/sQNq223Rr54'),
    Category(
        name: 'Smoothies', imageUrl: 'https://unsplash.com/photos/CrK843Pl9a4'),
    Category(name: 'Water', imageUrl: 'https://unsplash.com/photos/O_oWOsqVk_Y')
  ];
}
